Common testing utilities for dropwizard projects.
Enables tests to more easily read values from dropwizard configuration.yml
