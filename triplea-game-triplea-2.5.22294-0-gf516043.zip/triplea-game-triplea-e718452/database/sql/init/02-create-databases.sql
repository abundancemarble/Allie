create database lobby_db owner lobby_user;
create database maps_db owner maps_user;

