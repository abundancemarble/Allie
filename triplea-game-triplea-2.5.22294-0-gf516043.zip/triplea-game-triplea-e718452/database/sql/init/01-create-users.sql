create user lobby_user password 'postgres';
create user maps_user password 'postgres';

