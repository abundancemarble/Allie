comment on database maps_db is 'Database used to store, track and serve map information';

