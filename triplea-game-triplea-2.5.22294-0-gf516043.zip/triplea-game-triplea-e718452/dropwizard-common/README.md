Sub-project to make setting up a generic
dropwizard server easier to reduce boilerplate code.
