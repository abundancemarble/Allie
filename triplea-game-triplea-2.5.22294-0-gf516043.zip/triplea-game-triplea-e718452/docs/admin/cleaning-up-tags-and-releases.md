# Cleaning Up Tags and Releases

Delete tag from github repo (standard git command to delete a tag, https://github.com/triplea-game/triplea/issues/5608  ; TODO: give script here)

Delete release that is left behind: https://developer.github.com/v3/repos/releases/#delete-a-release

