# Team Communication

*Github Issues*: https://github.com/triplea-game/triplea/issues
- Primary means of communication, conversations are open and recorded for historical reference.
- Open, allows for team participation and task balancing

*Forum*: http://forums.triplea-game.org

Communication to the larger TripleA community. Feature and game changes discussions would belong here.
