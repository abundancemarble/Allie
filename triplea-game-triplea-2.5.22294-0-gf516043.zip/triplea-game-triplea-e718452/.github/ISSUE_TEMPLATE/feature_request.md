---
name: ⛔ Feature Request
about: Please go to https://forums.triplea-game.org/category/42/feature-requests-ideas
title: ''
labels: ''
assignees: ''

---

<!--
  Please do not use GitHub for feature requests. Instead,
  please visit our forum:

     https://forums.triplea-game.org/category/42/feature-requests-ideas

-->

