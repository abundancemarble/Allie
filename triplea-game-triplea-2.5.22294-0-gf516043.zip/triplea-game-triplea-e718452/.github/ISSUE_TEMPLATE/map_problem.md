---
name: "⛔ Map Specific Problems"
about: "Do not post here, search for a map discussion thread in forums: https://forums.triplea-game.org/category/5/maps-mods"
title: ''
labels: ''
assignees: ''

---

Do not report map specific problems here. Instead search for the map
in the forums:

     https://forums.triplea-game.org/category/5/maps-mods

