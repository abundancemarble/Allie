package games.strategy.engine.data;

/** An object that can be uniquely identified by name. */
public interface Named {
  String getName();
}
