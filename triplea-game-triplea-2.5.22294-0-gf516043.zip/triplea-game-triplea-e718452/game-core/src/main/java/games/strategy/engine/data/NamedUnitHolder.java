package games.strategy.engine.data;

/** A named object that contains a collection of {@link Unit}s. */
public interface NamedUnitHolder extends Named, UnitHolder {}
