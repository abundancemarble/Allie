package games.strategy.engine.lobby.client.login;

public enum LoginMode {
  REGISTRATION_REQUIRED,
  REGISTRATION_NOT_REQUIRED
}
